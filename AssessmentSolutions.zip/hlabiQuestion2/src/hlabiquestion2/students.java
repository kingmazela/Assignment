/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hlabiquestion2;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.*;
import java.util.Scanner;
import java.util.stream.Stream;

/**
 *
 * @author King-Hlabi
 */
class students {
    
    public Scanner scan = new Scanner(System.in);
    public String filename = "Students.txt";
    public String filename1 = "Results.txt";
    
    public String lastName;
    public String firstName;
    public String course;
    public int test1;
    public int test2;
    public int test3;
    public int exam;
    public float finalMark;
    public int grade;
    public String StudentDetails;
    public String toFile = null;
    List<Integer> list = new ArrayList<>();
    
    // This block calls the Questions
    public void setLastName(String lastName) {
        System.out.println("Please enter student last name:");
        lastName = scan.nextLine();
        this.lastName = lastName;
        
    }

    public void setFirstName(String firstName) {
        System.out.println("Please enter student first name:");
        firstName = scan.nextLine();
        this.firstName = firstName;
        
    }

    public void setCourse(String course) {
        System.out.println("Please enter student course:");
        course = scan.nextLine();
        this.course = course;
        
    }

    public void setTest1(int test1) {
        System.out.println("Please enter student test mark 1:");
        test1 = scan.nextInt();
        this.test1 = test1;
        
    }

    public void setTest2(int test2) {
        System.out.println("Please enter student test mark 2:");
        test2 = scan.nextInt();
        this.test2 = test2;
        
    }

    public void setTest3(int test3) {
        System.out.println("Please enter student test mark 3:");
        test3 = scan.nextInt();
        this.test3 = test3;
        
    }

    public void setExam(int exam) {
        System.out.println("Please enter exam mark:");
        exam = scan.nextInt();
        this.exam = exam;
        
    }

    public void setGrade(int grade) {
        System.out.println("Please enter student grade:");
        grade = scan.nextInt();
        this.grade = grade;
        
    }
    
    // Calculate method
    public void setFinalMark(float finalMark) throws IOException {
        float fmark = (float) (((this.getTest1()+this.getTest2()+this.getTest3())/3)*0.4+this.getExam()*0.6);
        this.finalMark = fmark;
        byte buf[] = filename.getBytes();
        ByteArrayInputStream input = new ByteArrayInputStream(buf);
        BufferedInputStream f = new BufferedInputStream(input);
        int c = 0;
        boolean marked = false;
//        while ((c = f.read()) != -1){
//            switch(c){
//                case 40:
//                    System.out.println("Student has failed");
//            }
//        }
        
    }
    // Write to files
    public void writeToFile(String toFile) throws FileNotFoundException, IOException{
        boolean appendd = true;// Writes to Student.txt
        BufferedWriter write = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename,appendd)));
        
        write.write("\n\nStudent name: "+ this.getFirstName());
        write.write("\nStudent last name: "+ this.getLastName());
        write.write("\nStudent Course: "+ this.getCourse());
        write.write("\nClass Test 1: "+ this.getTest1());
        write.write("\nClass Test 2: "+ this.getTest2());
        write.write("\nClass Test 3: "+ this.getTest3());
        write.write("\nStudent Grade: "+ this.getGrade());
        
        write.close();
        
        boolean append = true;// Writes to Resukts.txt
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename1,append)));
        
        writer.write("\n\nStudent Name: "+this.getFirstName());
        writer.write("\nStudent Last Name: "+this.getLastName());
        writer.write("\nStudent Course: "+this.getCourse());
        writer.write("\nStudent Grade: "+this.getGrade());
        writer.write("\nStudent Final Mark: "+this.getFinalMark());
        System.out.println("Entry saved successfully");
        writer.close();
        
    }
    // This block returns info
    public String getwriteToFile(){
       
        return toFile;
    }
    
     
    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getCourse() {
        return course;
    }

    public int getTest1() {
        return test1;
    }

    public int getTest2() {
        return test2;
    }

    public int getTest3() {
        return test3;
    }

    public int getExam() {
        return exam;
    }

    public float getFinalMark() {
        return finalMark;
    }

    public int getGrade() {
        return grade;
    }
    
    public void setStudentDetails() throws IOException{
        File file = new File(filename1);
        try(Stream<String> lines = Files.lines(file.toPath())){
            lines.forEach(line -> {
                System.out.println(line);
            });
        }
        
    }
    public String getStudentDetails(){
        return StudentDetails;
    }
    
   
    
    
}
