/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hlabiquestion2;

import java.util.Scanner;

/**
 *
 * @author King-Hlabi
 */
public class negativeNumberException extends students{
    
    Scanner numInput = new Scanner(System.in);
    int display;
    double avg = 0.0;
    double count = 0.0;
    double sum = 0.0;

    public void display(){// Exceptions
        while (numInput.hasNextDouble()){
            double negNum = numInput.nextDouble();
            if (negNum >= 0){
                sum += negNum;
                count++;
                avg = sum/count;
            }else{
                System.out.println("You entered "+count+" numbers averaging " +avg + ".");
                break;
            }   
        }   
    }
    public int getdisplay(){
        return display;
    }
    
    // Override methods in Student class
    @Override
    public int getTest1() {
        return super.getTest1();
    }

    @Override
    public int getTest2() {
        return super.getTest2();
    }

    @Override
    public int getTest3() {
        return super.getTest3();
    }

    @Override
    public int getExam() {
        return super.getExam(); 
    }

    @Override
    public void setTest1(int test1) {
        if (super.getTest1() != this.getdisplay()){
            System.out.println("Program does not allow negatives values");
            System.exit(0);
        }
        super.setTest1(test1); 
    }

    @Override
    public void setTest2(int test2) {
        if (super.getTest2() != this.getdisplay()){
            System.out.println("Program does not allow negatives values");
            System.exit(0);
        }
        super.setTest2(test2); 
    }

    @Override
    public void setTest3(int test3) {
        if (super.getTest3() != this.getdisplay()){
            System.out.println("Program does not allow negatives values");
            System.exit(0);
        }
        super.setTest3(test3); 
    }

    @Override
    public void setExam(int exam) {
        if (super.getExam() != this.getdisplay()){
            System.out.println("Program does not allow negatives values");
            System.exit(0);
        }
        super.setExam(exam); 
    }
    
    
    
}
