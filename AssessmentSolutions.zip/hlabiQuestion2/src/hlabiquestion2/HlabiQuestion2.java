/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hlabiquestion2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author King-Hlabi
 */
public class HlabiQuestion2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
       
        Program std = new Program();
        
        // Set enum
        // Give user options
        std.setEnum();
        
        
        
        
        
        // Display student award
        if (std.getFinalMark() < 39){
            System.out.println("Student has failed.");   
        }else if ((std.getFinalMark() > 40) && (std.getFinalMark() < 49)){
            System.out.println("Student is awarded a D symbol");
        }else if ((std.getFinalMark() > 50) && (std.getFinalMark() < 59)){
            System.out.println("Student is awarded a C symbol");
        }else if ((std.getFinalMark() > 60) && (std.getFinalMark() < 69)){
            System.out.println("Student is awarded a B symbol");
        }else if ((std.getFinalMark() > 70) && (std.getFinalMark() < 79)){
            System.out.println("Student is awarded a A symbol");
        }else{
            System.out.println("Student is awarded a A+ symbol");
        }
        
        
        
    }
    
}
