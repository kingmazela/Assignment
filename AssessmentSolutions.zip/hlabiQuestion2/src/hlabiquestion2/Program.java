/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hlabiquestion2;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author King-Hlabi
 */
public class Program extends negativeNumberException{
    
    Scanner scan = new Scanner(System.in);
    String userInput;
    
    // Configure Enum
    public void setEnum() throws IOException{
        System.out.println("Enter: 1 - To enter students\n2 - Display student information\n0 - Exit");
        userInput = scan.nextLine();
        
        if (userInput.equalsIgnoreCase("1")){// Insert a new student if number 1 is pressed
            System.out.println("Would you like to enter a new student?\n\nY - for Yes\nN - for No");
            String yes = scan.nextLine();
            
            do{// While the user instence is equal to yes
                // Repeat untill n pressed
                super.setFirstName(null);
        super.setLastName(null);
        super.setCourse(null);
        super.setExam(0);
        super.setTest1(0);
        super.setTest2(0);
        super.setTest3(0);
        super.setFinalMark(0);
        super.writeToFile(null);
        break;
            }while(yes.equalsIgnoreCase("y"));
            
            
            
        }else if (userInput.equalsIgnoreCase("2")){// View details if number 2 is pressed
            super.setStudentDetails();
        System.out.println(super.getStudentDetails());
        }else{// Exit if any other key is pressed
            System.exit(0);
        }
        
        
    }
    public String getEnum(){
        return userInput;
    }
    
    
    
    
    
    
}
