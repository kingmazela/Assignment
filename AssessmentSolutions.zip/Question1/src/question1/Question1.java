/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 *
 * @author King-Hlabi
 */
public class Question1 {

    /**
     * @param args the command line arguments
     */
    static List<Integer> list = (List<Integer>) new ArrayList<Integer>();
    public static void main(String[] args) {
        
        
        // Generate Random numbers from 0 to 99
        Random ran = new Random();
        int limit = ran.nextInt(99);
        for (int x = 0; x < limit;x++){
            list.add(x);
        }
        // Display numbers before sorting
        Collections.shuffle(list);
        for (int x = 0;x < 8;x++){
            System.out.println(list.get(x));
            
        }
        
        // Display number after sorting
        for (int i = 0; i < list.size();i++)
        {
            // Use the > operater to set Ascending
            // And < operater for Descending
            for (int j = list.size() -1; j > i;j--){
                if (list.get(i) > list.get(j)){
                    
                    list.set(i, list.set(j, list.get(i)));
                }
            }
        }
        // Display in Order
        System.out.println("\n\nNumbers in order:");
        for (int i : list){
            System.out.println(""+ i);
        }
        
        
        
    }
    
    
}
